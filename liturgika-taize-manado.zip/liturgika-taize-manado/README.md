# Liturgika Taize Manado

Blog informasi ibadah Taize, komunitas Taize di Manado,
dan spiritualitas kontemplatif pemuda GMIM.

Deploy:
1. Upload ke GitHub
2. Deploy ke Vercel
