export default function Home() {
  return (
    <main style={{padding:'40px',fontFamily:'sans-serif'}}>
      <h1>Liturgika Taize Manado</h1>
      <p>Informasi ibadah Taize, komunitas Taize Manado, dan spiritualitas kontemplatif.</p>
    </main>
  )
}
