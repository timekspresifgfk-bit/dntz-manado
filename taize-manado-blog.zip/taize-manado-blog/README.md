# Komunitas Taize Manado

Website komunitas online berbasis Next.js + TailwindCSS.

## Deploy ke Vercel
1. Upload project ke GitHub
2. Login ke https://vercel.com
3. Import repository
4. Klik Deploy
