export default function AdminPage() {
  return (
    <main style={{padding:'40px', fontFamily:'sans-serif'}}>
      <h1>Dashboard Admin</h1>
      <p>Kelola artikel komunitas Taize Manado.</p>
    </main>
  )
}
