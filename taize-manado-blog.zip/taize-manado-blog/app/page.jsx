export default function Home() {
  return (
    <main style={{padding:'40px', fontFamily:'sans-serif'}}>
      <h1>Komunitas Taize Manado</h1>
      <p>Website komunitas spiritualitas kontemplatif pemuda GMIM.</p>
    </main>
  )
}
